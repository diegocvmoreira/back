<?php
// Kariri.app — recebe os cadastros do site (JSON via POST) e salva no MySQL.
declare(strict_types=1);
require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
$cfg = kariri_config();

function responder(int $code, array $body): void {
    http_response_code($code);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

// Aceita apenas envios vindos do próprio site
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin && in_array($origin, $cfg['allowed_origins'], true)) {
    header("Access-Control-Allow-Origin: $origin");
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, ['ok' => false, 'erro' => 'Método não permitido.']);
if ($origin && !in_array($origin, $cfg['allowed_origins'], true)) responder(403, ['ok' => false, 'erro' => 'Origem não autorizada.']);

$raw = file_get_contents('php://input', false, null, 0, 10000);
$d = json_decode($raw ?: '', true);
if (!is_array($d)) responder(400, ['ok' => false, 'erro' => 'Dados inválidos.']);

// Armadilha anti-robô: campo invisível preenchido = descarta sem salvar
if (!empty($d['website'])) responder(201, ['ok' => true]);

$txt = fn(string $k, int $max) => mb_substr(trim((string)($d[$k] ?? '')), 0, $max);
$erros = [];

$tipo = $d['tipo'] ?? '';
if (!in_array($tipo, ['explorador', 'negocio'], true)) responder(400, ['ok' => false, 'erro' => 'Tipo de cadastro inválido.']);

$nome = $txt('nome', 120);
$email = $txt('email', 160);
$whatsapp = $txt('whatsapp', 20);
$cidade = $txt('cidade', 80);
$consent = ($d['consentimento'] ?? false) === true;

if (mb_strlen($nome) < 2) $erros['nome'] = 'Informe seu nome.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erros['email'] = 'Informe um e-mail válido.';
if (mb_strlen($cidade) < 2) $erros['cidade'] = 'Informe sua cidade.';
if (!$consent) $erros['consentimento'] = 'É necessário autorizar o uso dos dados.';
$whatsValido = (bool)preg_match('/^\+?[\d\s()\-]{10,20}$/', $whatsapp);
if ($tipo === 'explorador' && !$whatsValido) $erros['whatsapp'] = 'Informe um WhatsApp válido com DDD.';
if ($tipo === 'negocio' && $whatsapp !== '' && !$whatsValido) $erros['whatsapp'] = 'Informe um WhatsApp válido com DDD.';

$categorias = ['Turismo e natureza','Cultura e patrimônio','Gastronomia','Eventos e experiências','Compras e negócios locais','Serviços'];
$negocio = $categoria = '';
if ($tipo === 'negocio') {
    $negocio = $txt('negocio', 120);
    $categoria = (string)($d['categoria'] ?? '');
    if (mb_strlen($negocio) < 2) $erros['negocio'] = 'Informe o nome do negócio ou iniciativa.';
    if (!in_array($categoria, $categorias, true)) $erros['categoria'] = 'Selecione uma categoria.';
}
if ($erros) responder(422, ['ok' => false, 'erro' => 'Revise os campos destacados.', 'campos' => $erros]);

$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ua = mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);

try {
    $db = kariri_db();

    // Limite de envios por IP na última hora
    $q = $db->prepare('SELECT
        (SELECT COUNT(*) FROM cadastros_exploradores WHERE ip = ? AND criado_em > NOW() - INTERVAL 1 HOUR) +
        (SELECT COUNT(*) FROM cadastros_negocios     WHERE ip = ? AND criado_em > NOW() - INTERVAL 1 HOUR)');
    $q->execute([$ip, $ip]);
    if ((int)$q->fetchColumn() >= $cfg['rate_limit_per_hour']) responder(429, ['ok' => false, 'erro' => 'Muitas tentativas. Tente mais tarde.']);

    if ($tipo === 'explorador') {
        $st = $db->prepare('INSERT INTO cadastros_exploradores (nome, email, whatsapp, cidade, consentimento, ip, user_agent)
                            VALUES (?, ?, ?, ?, 1, ?, ?)
                            ON DUPLICATE KEY UPDATE nome = VALUES(nome), whatsapp = VALUES(whatsapp), cidade = VALUES(cidade), atualizado_em = NOW()');
        $st->execute([$nome, $email, $whatsapp, $cidade, $ip, $ua]);
    } else {
        $st = $db->prepare('INSERT INTO cadastros_negocios (nome, negocio, email, whatsapp, cidade, categoria, consentimento, ip, user_agent)
                            VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)');
        $st->execute([$nome, $negocio, $email, $whatsapp ?: null, $cidade, $categoria, $ip, $ua]);
    }
    responder(201, ['ok' => true]);
} catch (Throwable $e) {
    error_log('[kariri] ' . $e->getMessage());
    responder(500, ['ok' => false, 'erro' => 'Não foi possível salvar agora. Tente novamente.']);
}
