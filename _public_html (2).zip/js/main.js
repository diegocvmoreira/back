// Kariri.app — menu móvel e envio dos formulários para cadastro.php
(function () {
  var ENDPOINT = "cadastro.php"; // mesmo servidor da página

  document.getElementById("ano").textContent = new Date().getFullYear();

  var btn = document.querySelector(".menu-btn");
  var nav = document.getElementById("menu");
  function toggle(open) {
    nav.classList.toggle("open", open);
    btn.setAttribute("aria-expanded", String(open));
    btn.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
  }
  btn.addEventListener("click", function () { toggle(!nav.classList.contains("open")); });
  nav.querySelectorAll("a").forEach(function (a) { a.addEventListener("click", function () { toggle(false); }); });

  var WHATS = /^\+?[\d\s()-]{10,20}$/;
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function validar(tipo, d) {
    var e = {};
    if (d.nome.length < 2) e.nome = "Informe seu nome.";
    if (!EMAIL.test(d.email)) e.email = "Informe um e-mail válido.";
    if (d.cidade.length < 2) e.cidade = "Informe sua cidade.";
    if (tipo === "explorador" && !WHATS.test(d.whatsapp)) e.whatsapp = "Informe um WhatsApp válido com DDD.";
    if (tipo === "negocio") {
      if (d.whatsapp && !WHATS.test(d.whatsapp)) e.whatsapp = "Informe um WhatsApp válido com DDD.";
      if ((d.negocio || "").length < 2) e.negocio = "Informe o nome do negócio ou iniciativa.";
      if (!d.categoria) e.categoria = "Selecione uma categoria.";
    }
    if (!d.consentimento) e.consentimento = "É necessário autorizar o uso dos dados.";
    return e;
  }

  function mostrarErros(form, erros) {
    form.querySelectorAll(".err").forEach(function (n) { n.remove(); });
    form.querySelectorAll("[aria-invalid]").forEach(function (n) { n.removeAttribute("aria-invalid"); });
    Object.keys(erros).forEach(function (k) {
      var campo = form.elements[k];
      if (!campo) return;
      campo.setAttribute("aria-invalid", "true");
      var msg = document.createElement("span");
      msg.className = "err";
      msg.textContent = erros[k];
      campo.closest("label").appendChild(msg);
    });
  }

  function status(form, tipo, texto) {
    var s = form.querySelector(".status");
    s.className = "status " + tipo;
    s.textContent = texto;
  }

  document.querySelectorAll(".lead-form").forEach(function (form) {
    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var tipo = form.dataset.tipo;
      var d = {
        tipo: tipo,
        nome: form.elements.nome.value.trim(),
        email: form.elements.email.value.trim(),
        whatsapp: form.elements.whatsapp.value.trim(),
        cidade: form.elements.cidade.value.trim(),
        consentimento: form.elements.consentimento.checked,
        website: form.elements.website.value
      };
      if (tipo === "negocio") {
        d.negocio = form.elements.negocio.value.trim();
        d.categoria = form.elements.categoria.value;
      }
      var erros = validar(tipo, d);
      mostrarErros(form, erros);
      if (Object.keys(erros).length) { status(form, "bad", "Revise os campos destacados."); return; }

      var botao = form.querySelector("button");
      var rotulo = botao.textContent;
      botao.disabled = true; botao.textContent = "Enviando...";
      fetch(ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(d) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          if (res.ok && res.j.ok) {
            form.reset();
            status(form, "ok", "Cadastro recebido! Avisaremos sobre as novidades.");
          } else {
            if (res.j.campos) mostrarErros(form, res.j.campos);
            status(form, "bad", res.j.erro || "Não foi possível enviar agora. Tente novamente.");
          }
        })
        .catch(function () { status(form, "bad", "Não foi possível enviar agora. Verifique sua conexão."); })
        .finally(function () { botao.disabled = false; botao.textContent = rotulo; });
    });
  });
})();
