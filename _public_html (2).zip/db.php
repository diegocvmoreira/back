<?php
$cfg = require '/home/USUARIO/private/kariri-landing-config.php';


// Conexão PDO com o banco MySQL (o mesmo que você administra pelo phpMyAdmin).
function kariri_config(): array {
    static $cfg = null;
    if ($cfg === null) $cfg = require __DIR__ . '/config.php';
    return $cfg;
}

function kariri_db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $c = kariri_config();
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $c['db_host'], $c['db_port'], $c['db_name'], $c['db_charset']);
    $pdo = new PDO($dsn, $c['db_user'], $c['db_pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}
