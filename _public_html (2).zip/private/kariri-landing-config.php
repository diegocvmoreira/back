<?php
// Kariri.app — configuração do banco (MySQL/MariaDB administrado pelo phpMyAdmin).
// Preencha com os dados da sua hospedagem. Não publique este arquivo com senhas em repositórios.
return [
    'db_host'    => 'localhost',
    'db_port'    => 3306,
    'db_name'    => 'u172388780_kariri_leads',
    'db_user'    => 'u172388780_diego',
    'db_pass'    => 'B@otafogo09',
    'db_charset' => 'utf8mb4',

    // Endereços onde o site está publicado (aceita envios só deles).
    'allowed_origins' => [
        'https://kariri.app.br',
        'https://www.kariri.app.br',
    ],

    // Máximo de envios por IP a cada hora.
    'rate_limit_per_hour' => 10,
];
