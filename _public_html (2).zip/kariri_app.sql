-- Kariri.app — tabelas de cadastro de interessados
-- Importe pelo phpMyAdmin (aba "Importar") ou cole na aba "SQL".

CREATE DATABASE IF NOT EXISTS kariri_app
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kariri_app;

CREATE TABLE IF NOT EXISTS cadastros_exploradores (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) NOT NULL,
  whatsapp      VARCHAR(20)  NOT NULL,
  cidade        VARCHAR(80)  NOT NULL,
  consentimento TINYINT(1)   NOT NULL DEFAULT 1,
  ip            VARCHAR(45)  NULL,
  user_agent    VARCHAR(255) NULL,
  criado_em     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_explorador_email (email),
  KEY idx_explorador_ip_data (ip, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cadastros_negocios (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome          VARCHAR(120) NOT NULL,
  negocio       VARCHAR(120) NOT NULL,
  email         VARCHAR(160) NOT NULL,
  whatsapp      VARCHAR(20)  NULL,
  cidade        VARCHAR(80)  NOT NULL,
  categoria     ENUM('Turismo e natureza','Cultura e patrimônio','Gastronomia',
                     'Eventos e experiências','Compras e negócios locais','Serviços') NOT NULL,
  consentimento TINYINT(1)   NOT NULL DEFAULT 1,
  ip            VARCHAR(45)  NULL,
  user_agent    VARCHAR(255) NULL,
  criado_em     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_negocio_email (email),
  KEY idx_negocio_categoria (categoria),
  KEY idx_negocio_ip_data (ip, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
