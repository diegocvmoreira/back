<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__ . '/../kariri-api/vendor/autoload.php';

$app = require_once __DIR__ . '/../kariri-api/bootstrap/app.php';

$app->handleRequest(
    Illuminate\Http\Request::capture()
);
