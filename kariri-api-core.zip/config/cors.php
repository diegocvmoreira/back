<?php

/*
 * CORS da API Kariri.
 * Origens extras podem ser adicionadas no .env sem editar código:
 * CORS_ALLOWED_ORIGINS=https://meu-preview.exemplo.com,https://outro.com
 */
$extraOrigins = array_filter(array_map(
    'trim',
    explode(',', (string) env('CORS_ALLOWED_ORIGINS', ''))
));

return [
    'paths' => [
        'api/*',
        'sanctum/csrf-cookie',
    ],

    'allowed_methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],

    'allowed_origins' => array_merge([
        'https://kariri.app.br',
        'https://www.kariri.app.br',
        'http://localhost:3000',
    ], $extraOrigins),

    // Pré-visualização do Google AI Studio (ais-dev-*/ais-pre-*.run.app).
    // REMOVER este padrão quando o app sair do AI Studio.
    'allowed_origins_patterns' => [
        '#^https://ais-(dev|pre)-[a-z0-9-]+\.[a-z0-9-]+\.run\.app$#',
    ],

    'allowed_headers' => [
        'Accept',
        'Content-Type',
        'Authorization',
        'Origin',
        'X-Requested-With',
        'X-XSRF-TOKEN',
    ],

    'exposed_headers' => [
        'X-RateLimit-Limit',
        'X-RateLimit-Remaining',
    ],

    'max_age' => 86400,

    'supports_credentials' => false,
];
